# Scraper for Texas 1st Court of Appeals
# CourtID: txctapp1
# Court Short Name: TX
# Author: Andrei Chelaru
# Reviewer:
# Date: 2014-07-10


from juriscraper.opinions.united_states.state import texapp


class Site(texapp.Site):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.court_id = self.__module__
        self.court_number = "01"
        self.checkbox = 2
