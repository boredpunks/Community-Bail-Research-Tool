"""Scraper for Second Circuit
CourtID: ca2
Contact:
  Webmaster@ca2.uscourts.gov ('Calendar Team' handles updates, and is responsive)
  ecfhelpdesk@ca2.uscourts.gov
  Shane_Clouden@ca2.uscourts.gov

History:
  2026-04-27: site migrated from the IsysWeb endpoint to a dtSearch
  POST endpoint #1919.
  2026-06-05: caption moved from plain text into an anchor element #1991.
  2026-06-12: the decisions endpoint renamed the `Date Posted` label to
  `Date` and moved the caption into a client-side <script> #2001.
"""

import re
from datetime import date, datetime, timedelta
from html import unescape
from urllib.parse import urljoin

from typing_extensions import override

from juriscraper.AbstractSite import logger
from juriscraper.lib.string_utils import titlecase
from juriscraper.OpinionSiteLinear import OpinionSiteLinear


class Site(OpinionSiteLinear):
    base_url = "https://ww3.ca2.uscourts.gov"
    search_url = urljoin(base_url, "/dtSearch/dtisapi6.dll")
    # The dtSearch index ID for Opinions. The companion ID for Summary
    # Orders is `*{aad0964f04f3e9c420e057fd415efe0c} SUM` (see ca2_u).
    index = "*{aa12e167958cdbcaa709fa14b9161a4a} OPN"
    first_opinion_date = datetime(2007, 1, 1)
    days_interval = 15

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.court_id = self.__module__
        self.url = self.search_url
        self.method = "POST"
        self.status = "Published"

        self.end_date = date.today()
        self.start_date = self.end_date - timedelta(days=self.days_interval)
        self._update_parameters()
        self.make_backscrape_iterable(kwargs)

    def _update_parameters(self) -> None:
        """Build the POST body matching the form on /decisions.html.

        The dtSearch engine expects the date range both as the
        StartDate/EndDate inputs and embedded in the `fileConditions`
        xfilter expression (the form's JS keeps both in sync).
        """
        date_filter = (
            f'xfilter(date "{self.start_date:%Y/%m/%d}'
            f'~~{self.end_date:%Y/%m/%d}")'
        )
        self.parameters = {
            "index": self.index,
            "request": "",
            "searchType": "allwords",
            "cmd": "search",
            "SearchForm": "%%SearchForm%%",
            "dtsPdfWh": "*",
            "OrigSearchForm": "/decisions.html",
            "autoStopLimit": "5000",
            "pageSize": "1000",
            "sort": "date",
            "StartDate": self.start_date.strftime("%Y-%m-%d"),
            "EndDate": self.end_date.strftime("%Y-%m-%d"),
            "fileConditions": date_filter,
            "booleanConditions": "",
        }

    @override
    def _process_html(self) -> None:
        for row in self.html.xpath('//table[@class="ResultsTable"]/tr'):
            anchor = row.xpath('.//td[@class="ResultsItemLeft"]/a')
            if not anchor:
                logger.warning("ca2: row without anchor, skipping")
                continue
            url = urljoin(self.base_url, anchor[0].get("href", "").strip())
            docket = anchor[0].text_content().strip()

            right = row.xpath('.//td[@class="ResultsItemRight"]')[0]
            fields = self._parse_right_cell(right)
            # label renamed `Date Posted` -> `Date` on 2026-06-12 #2001
            posted = fields.get("Date Posted") or fields.get("Date")
            caption = fields.get("Caption")
            if not (url and docket and posted and caption):
                logger.error(
                    "ca2: incomplete row docket=%r url=%r posted=%r caption=%r",
                    docket,
                    url,
                    posted,
                    caption,
                )
                continue

            self.cases.append(
                {
                    "url": url,
                    "docket": docket,
                    "name": titlecase(caption),
                    "date": posted,
                }
            )

    @staticmethod
    def _clean(text: str) -> str:
        """Strip whitespace and the U+FEFF BOM that the dtSearch oral-arg
        endpoint prefixes to every text node. `str.strip()` does not
        remove U+FEFF, so handle it explicitly. Safe to use on opinion
        text too (no BOM there, just a no-op).
        """
        return (text or "").strip().lstrip("﻿").strip()

    @classmethod
    def _parse_right_cell(cls, cell) -> dict:
        """Pull labelled values out of a dtSearch result's right TD.

        Opinion cells look like:
            <B>Date Posted: </B>4/23/2026<BR>
            <B>Caption: </B><a href="..._opn.pdf" ...>Richardson v. ...</a><BR>
            <B>Type: </B>/decisions/OPN<BR>
        Oral-arg cells use `Caption` / `Date Argued` labels instead. Each
        <b> label's value lives in its `.tail`, except the opinion Caption,
        which since 2026-06 is wrapped in an anchor that follows the label
        (#1991). Oral-arg captions are still plain text in the tail.

        As of 2026-06-12 the decisions endpoint no longer emits a
        `<b>Caption:</b>` element at all: it writes the caption from a
        client-side <script> via `document.write`, so lxml only sees the
        `Date` and `Type` labels. Recover the caption from the script's
        `captionStr` JS variable as a fallback #2001.
        """
        out: dict[str, str] = {}
        for b in cell.iter("b"):
            label = cls._clean(b.text or "").rstrip(":").strip()
            value = cls._clean(b.tail or "")
            if not value:
                # value may be wrapped in an element following the label,
                # e.g. the Caption anchor #1991
                sibling = b.getnext()
                if sibling is not None and sibling.tag == "a":
                    value = cls._clean(sibling.text_content())
            if label:
                out[label] = value

        if not out.get("Caption"):
            for script in cell.iter("script"):
                if match := re.search(
                    r'captionStr\s*=\s*"(.*?)"', script.text or ""
                ):
                    # script text is CDATA, so HTML entities (&amp;) are
                    # not decoded by lxml: unescape them ourselves
                    caption = cls._clean(unescape(match.group(1)))
                    if caption:
                        out["Caption"] = caption
                        break

        return out

    async def _download_backwards(self, dates: tuple[date, date]) -> None:
        self.start_date, self.end_date = dates
        self._update_parameters()
        self.html = await self._download()
        if self.html is not None:
            self._process_html()
