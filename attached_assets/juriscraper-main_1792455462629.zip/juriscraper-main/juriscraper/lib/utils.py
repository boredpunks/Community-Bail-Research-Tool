import re
import traceback
from collections.abc import Callable, Hashable, Iterable
from datetime import date, datetime, timedelta
from itertools import chain, islice, tee
from typing import Any, Protocol, TypeVar, cast

from httpx import HTTPError

from juriscraper.lib.exceptions import (
    EmptyFileError,
    InsanityException,
    NoDownloadUrlError,
    UnexpectedContentTypeError,
)
from juriscraper.lib.log_tools import make_default_logger
from juriscraper.lib.type_utils import OpinionType

from .date_utils import fix_future_year_typo
from .string_utils import (
    clean_string,
    convert_date_string,
    force_unicode,
    harmonize,
)

logger = make_default_logger()


def sanity_check_dates(
    dates_and_names: list[tuple[object, object, object]], court_id: str
) -> None:
    """Checks that dates are datetime.date objects and that they are not in the future

    :param dates_and_names: a 3 member tuple (case_date, case_name, date_is_approximate)
    :param court_id: for logging purposes
    """
    # check that no date is in the future
    future_date_count = 0
    for case_date, case_name, date_is_approximate in dates_and_names:
        if not isinstance(case_date, date):
            raise InsanityException(
                f"{court_id}: Member of case_dates list not a valid date object. "
                f"Instead it is: {type(case_date)} with value: {case_date}"
            )

        # If a date is approximate, then it may be set in the future until
        # half of the year has passed. Ignore this case
        # dates should not be in the future. Tolerate a week
        if not date_is_approximate and case_date > (
            date.today() + timedelta(days=7)
        ):
            future_date_count += 1
            error = f"{court_id}: {case_date} date is in the future. Case '{case_name}'"
            logger.error(error)

            # Interrupt data ingestion if more than 1 record has a bad date
            if future_date_count > 1:
                raise InsanityException(
                    f"More than 1 case has a date in the future. Last case: {error}"
                )


def sanity_check_case_names(case_names: list[str]) -> None:
    """Check that no name is an empty string

    :param case_names: ordered list of case names
    """
    prior_case_name = None
    for i, name in enumerate(case_names):
        if not name.strip():
            raise InsanityException(
                "Item with index %s has an empty case name. The prior "
                "item had case name of: %s" % (i, prior_case_name)
            )
        prior_case_name = name


def sanity_check_opinion_types(
    sub_opinions: list[dict[Hashable, object]],
) -> None:
    """Check opinion type assignment rules within a cluster

    :param sub_opinions: list of sub_opinion dictionaries
    :raises InsanityException: if any rule is violated
    """
    if not sub_opinions:
        return

    # Rule 1: At most 1 MAJORITY opinion per cluster
    majority_count = sum(
        1
        for op in sub_opinions
        if op.get("types") == OpinionType.MAJORITY.value
    )
    if majority_count > 1:
        raise InsanityException(
            f"Cluster has {majority_count} MAJORITY opinions, expected at most 1 {sub_opinions}"
        )

    # Rule 2: COMBINED type only valid in single-opinion clusters
    has_combined = any(
        op.get("types") == OpinionType.COMBINED.value for op in sub_opinions
    )
    if has_combined and len(sub_opinions) > 1:
        raise InsanityException(
            f"COMBINED type used in cluster with {len(sub_opinions)} sub_opinions, "
            "expected only 1"
        )

    # Rule 3: UNANIMOUS requires per_curiam=True
    for op in sub_opinions:
        if op.get("types") == OpinionType.UNANIMOUS.value and not op.get(
            "per_curiam"
        ):
            raise InsanityException(
                "UNANIMOUS opinion must have per_curiam=True"
            )


def clean_attribute(name: str, value: Any) -> Any:
    """Performs standard cleaning by type; and some specific cleaning by name

    :param name: attribute standard name
    :param value: attribute value
    :return: cleaned value
    """
    if name == "download_urls":
        return value.strip()
    elif name == "case_dates" and not isinstance(value, datetime | date):
        value = convert_date_string(value)

    if isinstance(value, str):
        value = clean_string(value)
    elif isinstance(value, datetime):
        value = value.date()
        # Sanitize case date, fix typo of current year if present
        fixed_date = fix_future_year_typo(value)
        if fixed_date != value:
            logger.info("Date year typo detected. Converting %s to %s")
            value = fixed_date

    if name in ["case_names", "docket_numbers"]:
        value = harmonize(value)

    return value


# TODO[Python3.12]: Replace with use of nice synta
_IterableObjectT = TypeVar("_IterableObjectT")


def previous_and_next(
    some_iterable: Iterable[_IterableObjectT],
) -> Iterable[
    tuple[_IterableObjectT | None, _IterableObjectT, _IterableObjectT | None]
]:
    """Provide previous and next values while iterating a list.

    This is from: http://stackoverflow.com/a/1012089/64911

    This will allow you to lazily iterate a list such that as you iterate, you
    get a tuple containing the previous, current, and next value.
    """
    prevs: Iterable[_IterableObjectT | None]
    items: Iterable[_IterableObjectT]
    nexts: Iterable[_IterableObjectT | None]

    prevs, items, nexts = tee(some_iterable, 3)
    prevs = chain([None], prevs)
    nexts = chain(islice(nexts, 1, None), [None])
    return zip(prevs, items, nexts)


# TODO[Python3.12]: Replace with use of nice syntax
_CourtObjectT = TypeVar("_CourtObjectT")


def clean_court_object(obj: _CourtObjectT) -> _CourtObjectT:
    """Clean a list or dict that is part of a scraping response.

    Court data is notoriously horrible, so this function attempts to clean up
    common problems that it may have. You can pass in either a dict or a list,
    and it will be cleaned recursively.

    Supported cleanup includes:

    1. Removing spaces before commas.
    1. Stripping whitespace from the ends.
    1. Normalizing white space.
    1. Forcing unicode.

    :param obj: A dict or list containing string objects.
    :return: A dict or list with the string values cleaned.
    """
    if isinstance(obj, list):
        # type checker cannot infer correctness, so we help it along with
        # erasure here and a `cast` below
        obj_list: list[object] = obj
        cleaned_list = [clean_court_object(i) for i in obj_list]
        return cast(_CourtObjectT, cleaned_list)
    elif isinstance(obj, dict):
        # type checker cannot infer correctness, so we help it along with
        # erasure here and a `cast` below
        obj_dict: dict[Hashable, object] = obj
        cleaned_dict = {k: clean_court_object(v) for k, v in obj_dict.items()}
        return cast(_CourtObjectT, cleaned_dict)
    elif isinstance(obj, str):
        s = " ".join(obj.strip().split())
        s = force_unicode(s)
        s = re.sub(r"\s+,", ",", s)
        # type checker cannot infer correctness, so we help it along with
        # this `cast`.
        return cast(_CourtObjectT, s)
    else:
        return obj


_DownloadT = TypeVar("_DownloadT")


class PaginatedHtmlBackscrapeSite(Protocol[_DownloadT]):
    court_id: str
    url: str
    cases: list[dict[str, Any]]
    html: _DownloadT | None  # TODO: Fix this to `HtmlElement`

    async def _download(self) -> _DownloadT: ...

    async def _process_html(self) -> None: ...


_PaginatedHtmlBackscrapeSiteT = TypeVar(
    "_PaginatedHtmlBackscrapeSiteT", bound=PaginatedHtmlBackscrapeSite[Any]
)


async def backscrape_over_paginated_results(
    first_page: int,
    last_page: int,
    start_date: date,
    end_date: date,
    date_fmt: str,
    site: _PaginatedHtmlBackscrapeSiteT,
    prepare_request_fn: Callable[[int, _PaginatedHtmlBackscrapeSiteT], None]
    | None = None,
    url_template: str = "",
) -> list[dict[str, Any]]:
    """
    Iterates over consecutive pages, looking for cases in a specific date range
    Of use when the page offers no date filters, so one must look through all
    the pages. Assumes the page is returning results ordered by date

    :param first_page: integer of the first page
    :param last_page: integer of the last page
    :param start_date: cases with a date greater than this value will be collected
    :param end_date: cases with a date lesses than this value will be collected
    :param date_fmt: date format to parse case dates
    :param site: the site object
    :param prepare_request_fn: a function that takes as arguments the page number
        and the site object, and modifies the site's attribute to prepare
        the request before `site._download()` is called.
        If not passed, it will try to use the url_template argument
    :param url_template: string to apply .format() to, like "url&page={}"
        where the argument to pass will be the page number

    :return: the list of cases between the dates
    """
    cases = []

    if isinstance(start_date, datetime):
        start_date = start_date.date()
    if isinstance(end_date, datetime):
        end_date = end_date.date()

    for page in range(first_page, last_page):
        site.cases = []  # reset results container

        if prepare_request_fn:
            prepare_request_fn(page, site)
        else:
            site.url = url_template.format(page)

        try:
            site.html = await site._download()
            await site._process_html()
        except HTTPError:
            # if the request returned and error, take advantage of the cases
            # already downloaded. This may also be a case when the last page
            # was unknown, and `last_page + 1` generates an error
            logger.info(
                "Error while downloading, breaking pagination at page %s", page
            )
            logger.debug("%s", traceback.format_exc())
            break

        if not site.cases:
            logger.info("No cases in this page; breaking the loop")
            break

        # results are ordered by desceding date
        earliest = datetime.strptime(site.cases[-1]["date"], date_fmt).date()
        latest = datetime.strptime(site.cases[0]["date"], date_fmt).date()
        logger.info(
            "Results page %s has date range %s to %s", page, earliest, latest
        )

        # no intersection between date ranges
        if max(earliest, start_date) >= min(latest, end_date):
            # if earliest date from results is earlier than
            # the start date, no need to iterate any further
            if earliest < start_date:
                logger.info(
                    "Finishing backscrape: earliest results date is %s earlier than start %s",
                    earliest,
                    start_date,
                )
                break
            continue

        # if there is an intersection, test every case and
        # collect the matching cases
        for case in site.cases:
            case_date = datetime.strptime(case["date"], date_fmt).date()
            if case_date < end_date and case_date > start_date:
                cases.append(case)

    return cases


def check_expected_content_types(
    site: Any, response: Any, download_url: str
) -> None:
    """Raise UnexpectedContentTypeError if response Content-Type is not allowed.

    :param site: scraper instance
    :param response: httpx Response or urllib HTTPResponse
    :param download_url: URL that was fetched
    """
    expected_content_types = site.expected_content_types
    court_id = site.court_id

    # test for expected content type (thanks mont for nil)
    if not expected_content_types:
        return

    # Support both httpx (headers.get) and urllib (getheader) responses
    if hasattr(response, "getheader"):
        raw_ct = response.getheader("Content-Type", "")
    else:
        raw_ct = response.headers.get("Content-Type", "")

    # Clean up content types like "application/pdf;charset=utf-8"
    # and 'application/octet-stream; charset=UTF-8'
    content_type = raw_ct.lower().split(";")[0].strip()
    m = any(content_type in mime.lower() for mime in expected_content_types)

    if not m:
        court_str = court_id.split(".")[-1].split("_")[0]
        fingerprint = [f"{court_str}-unexpected-content-type"]
        msg = f"'{download_url}' '{content_type}' not in {expected_content_types}"
        raise UnexpectedContentTypeError(
            msg, fingerprint=fingerprint, data={"response": response}
        )


def check_download_url(download_url: str) -> None:
    """Raise NoDownloadUrlError if download_url is empty or falsy."""
    if not download_url:
        raise NoDownloadUrlError(download_url)


def check_empty_downloaded_file(
    response: bytes | Any, download_url: str
) -> None:
    """Raise EmptyFileError if the downloaded content is empty.

    :param response: raw bytes or httpx Response with .content attribute
    :param download_url: URL that was fetched
    """
    # Support both httpx responses (.content) and raw bytes from urllib
    content = response if isinstance(response, bytes) else response.content
    if len(content) == 0:
        raise EmptyFileError(f"EmptyFileError: '{download_url}'")
