# We import the entire datetime library because otherwise we run into
# conflicts in our isinstance statements.
import datetime
from collections.abc import Iterable
from itertools import zip_longest
from math import ceil
from typing import TypeVar, cast

from dateutil.parser import parser, parserinfo
from dateutil.rrule import DAILY, rrule

MISSPELLINGS = {
    "Febraury": "February",
    "Feburay": "February",
    "Sepetmber": "September",
    "Sepember": "September",
    "Term": "1",
}


def json_date_handler(obj: object) -> str | None:
    return (
        obj.isoformat()
        if isinstance(obj, datetime.datetime | datetime.date)
        else None
    )


class BetterInfo(parserinfo):
    """Removes tokens to provide better support for splitting out multiple
    dates.

    By default, the JUMP variable is:

        JUMP = [" ", ".", ",", ";", "-", "/", "'",
                "at", "on", "and", "ad", "m", "t", "of",
                "st", "nd", "rd", "th"]

    This assumes that a single date is being sent to timesplit, and that that
    date might contain tokens like "and", ";", or "on". But when you're
    sending multiple dates, you are more likely to have something like this:

        'February 5, 1980; March 14, 1980 and May 28, 1980.

    This uses the semicolon and the word "and" to separate dates, so we need
    to allow them for splitting. This class makes that possible by removing
    them from the JUMP variable.
    """

    # m from a.m/p.m, t from ISO T separator
    JUMP = [
        " ",
        ".",
        ",",
        "-",
        "/",
        "'",
        "ad",
        "m",
        "t",
        "st",
        "nd",
        "rd",
        "th",
    ]

    def __init__(self):
        super().__init__()


p = parser(info=BetterInfo())
info = p.info


def timetoken(token: str) -> bool:
    try:
        float(token)
        return True
    except ValueError:
        pass
    return any(
        f(token)
        for f in (
            info.jump,
            info.weekday,
            info.month,
            info.hms,
            info.ampm,
            info.pertain,
            info.utczone,
            info.tzoffset,
        )
    )


def quarter(month: int) -> int:
    """
    :param month: Any month, as an int.
    :return: The quarter of the year during which that month occurs (1-4)
    """
    return int(ceil(float(month) / 3))


def is_first_month_in_quarter(month: int) -> int:
    """

    :param month: Any month as an int.
    :return: Whether that month is the first month in a quarter
    """
    return month in [1, 4, 7, 10]


_SomeDateT = TypeVar("_SomeDateT", datetime.datetime, datetime.date)


def fix_future_year_typo(future_date: _SomeDateT) -> _SomeDateT:
    """Fix current year typo, convert 2106 to 2016 in year 2016"""
    current_year = str(datetime.date.today().year)
    transposed_year = (
        current_year[0] + current_year[2] + current_year[1] + current_year[3]
    )
    if transposed_year == str(future_date.year):
        return future_date.replace(year=int(current_year))
    return future_date


def make_date_range_tuples(
    start: _SomeDateT, end: _SomeDateT, gap: int
) -> list[tuple[_SomeDateT, _SomeDateT]]:
    """Make an iterable of date tuples for use in iterating forms

    For example, a form might allow start and end dates and you want to iterate
    it one week at a time starting on Jan 1 and ending on Feb 3:

    >>> make_date_range_tuples(date(2017, 1, 1), date(2017, 2, 3), 7)
    [(Jan 1, Jan 7), (Jan 8, Jan 14), (Jan 15, Jan 21), (Jan 22, Jan 28),
     (Jan 29, Feb 3)]

    :param start: date when the query should start.
    :param end: date when the query should end.
    :param gap: the number of days, inclusive, that a query should span at a
    time.

    :rtype: list(tuple)
    :returns: list of start, end tuples
    """

    def to_any_date(dt: datetime.datetime) -> _SomeDateT:
        # Python generics can't be reified; we must key off the input values
        # and to infer the type manually.
        if all(isinstance(d, datetime.datetime) for d in (start, end)):
            # both start and end are `datetime`-> `_SomeDateT` is `datetime`
            return cast(_SomeDateT, dt)
        else:
            return cast(_SomeDateT, dt.date())

    # We create a list of start dates and a list of end dates, then zip them
    # together. If end_dates is shorter than start_dates, fill the last value
    # with the original end date.
    start_dates = [
        to_any_date(d)
        for d in rrule(DAILY, interval=gap, dtstart=start, until=end)
    ]
    end_start = start + datetime.timedelta(days=gap - 1)
    end_dates = [
        to_any_date(d)
        for d in rrule(DAILY, interval=gap, dtstart=end_start, until=end)
    ]
    if isinstance(end, datetime.datetime):
        end_date = to_any_date(end)
    else:
        end_date = end
    return list(zip_longest(start_dates, end_dates, fillvalue=end_date))


def unique_year_month(
    date_list: list[_SomeDateT] | list[tuple[_SomeDateT]],
) -> list[_SomeDateT]:
    """Takes a list of dates or date tuples, and reduces it
    to date objects with unique year-months pairs
    TODO: 1-tuple input is not correct; it should change to reflect usage.
    TODO: A `NamedTuple` may be the most appropriate return type. Setting aside
     `datetime.date` and `datetime.datetime` inheritance trouble, consumers are
     do not appear to use the day of the returned values - only year and month
     are used …for URL construction and not calendar math.


    :param date_list: a list containing dates or tuples of dates
        default make_backscrape_iterable returns date tuples
    :return: a list with date objects of unique year-month pairs
    """
    unique_list = []
    seen_year_months = set()

    for obj in date_list:
        iterable: Iterable[_SomeDateT]
        if isinstance(obj, datetime.datetime | datetime.date):
            iterable = (obj,)
        else:
            iterable = obj

        for date_obj in iterable:
            ym = date_obj.strftime("%Y%m")
            if ym in seen_year_months:
                continue
            seen_year_months.add(ym)
            unique_list.append(date_obj)

    return unique_list
