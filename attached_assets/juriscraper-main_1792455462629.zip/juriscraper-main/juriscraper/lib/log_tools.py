import getpass
import logging.handlers
import os
import sys
import traceback

LOG_FILENAME = os.environ.get(
    "JURISCRAPER_LOG", "/var/log/juriscraper/debug.log"
)


def _errprint(message: str) -> None:
    print(message, file=sys.stderr)


def make_default_logger(file_path: str = LOG_FILENAME) -> logging.Logger:
    """Boilerplate and testing code to create a logger. If we run into an
    IOError, issue a warning and use the NullHandler so things work without
    functional logging.

    :return: a logger object
    """
    logger = logging.getLogger(__name__)
    if not len(logger.handlers):
        logger.setLevel(logging.DEBUG)
        # Create a handler and attach it to the logger
        try:
            handler = logging.handlers.RotatingFileHandler(
                file_path, maxBytes=5120000, backupCount=7
            )
        except OSError as e:
            if e.errno == 2:
                _errprint(
                    "\nWarning: %s: %s. "
                    "Have you created the directory for the log?"
                    % (
                        e.strerror,
                        file_path,
                    )
                )
            elif e.errno == 13:
                _errprint(
                    "\nWarning: %s: %s. "
                    "Cannot access file as user: %s"
                    % (
                        e.strerror,
                        file_path,
                        getpass.getuser(),
                    )
                )
            else:
                _errprint(
                    "\nIOError [%s]: %s\n%s"
                    % (e.errno, e.strerror, traceback.format_exc())
                )
            _errprint(
                "Juriscraper will continue to run, and all logs will be "
                "sent to stderr."
            )
            handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(
            logging.Formatter("%(asctime)s - %(levelname)s: %(message)s")
        )
        logger.addHandler(handler)
    return logger
