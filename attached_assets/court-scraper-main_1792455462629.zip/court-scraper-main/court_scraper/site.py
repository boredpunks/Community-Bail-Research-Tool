from court_scraper import utils
from court_scraper.sites_meta import SitesMeta


class Site:
    def __new__(cls, *args, **kwargs):
        place_id = args[0]
        meta = cls.get_site_meta(cls, place_id)
        site_type = meta["site_type"]
        site_class = utils.get_site_class(place_id, site_type)
        # Odyssey is super non-standard
        if site_type == "odyssey":
            # Set defaults for omitted kwargs
            if "url" not in kwargs:
                kwargs["url"] = meta["home_url"]
            if "headless" not in kwargs:
                kwargs["headless"] = True
            final_args = [place_id]
        else:
            final_args = args
        return site_class(*final_args, **kwargs)

    def get_site_meta(cls, place_id):
        sm = SitesMeta()
        state = place_id[0:2]
        county = place_id[3:].replace("_", " ").strip()
        key = (state, county)
        site_info = sm.data[key]
        cls._site_meta = site_info
        return cls._site_meta
